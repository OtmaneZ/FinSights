import FinancialDashboard from '@/components/FinancialDashboard'
import CTAFixed from '@/components/CTAFixed'

export default function DashboardPage() {
    return (
        <main className="finsight-body">
            {/* Header */}
            <header className="finsight-header">
                <div className="finsight-nav-container">
                    <div className="finsight-brand-container">
                        <h1 className="finsight-brand">FinSight</h1>
                        <span className="finsight-brand-subtitle">Dashboard</span>
                    </div>
                    <nav className="finsight-nav-menu finsight-nav-hidden">
                        <a href="/" className="finsight-nav-link">Accueil</a>
                        <a href="/dashboard" className="finsight-nav-link finsight-nav-active">Dashboard</a>
                        <a href="/methodologie" className="finsight-nav-link">Méthodologie</a>
                        <a href="/copilot" className="finsight-nav-link">Copilote IA</a>
                    </nav>
                </div>
            </header>

            <div className="finsight-main">
                <FinancialDashboard />
            </div>

            {/* CTA Fixe */}
            <CTAFixed />

            {/* Footer */}
            <footer className="finsight-footer">
                <div className="finsight-footer-content">
                    <div className="finsight-footer-center">
                        <p className="finsight-footer-main">
                            Prototype développé par <span className="finsight-footer-highlight">Otmane Boulahia</span> — <span className="finsight-footer-brand">Zine Insight</span>
                        </p>
                    </div>
                </div>
            </footer>
        </main>
    )
}